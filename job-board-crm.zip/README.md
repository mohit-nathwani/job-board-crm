# Job Board CRM

Next.js 14 + Tailwind + Netlify Functions.

Deployed via Netlify.