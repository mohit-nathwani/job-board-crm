export default function Home() {
  return (
    <main className="min-h-screen flex items-center justify-center bg-slate-50 text-2xl font-bold">
      Hello World – CRM Dashboard is Live ✅
    </main>
  );
}